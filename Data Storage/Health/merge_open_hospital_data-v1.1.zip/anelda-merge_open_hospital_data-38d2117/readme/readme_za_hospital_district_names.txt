Source: File = http://www.health.gov.za/index.php/2014-03-17-09-09-38/reports/category/424-reports-2017# District HealthBarometer info 2016 2017 06 Feb 2018 (a spreadsheet)
Sheet:  ‘Seq’
New File: za_hospital_district_names.csv

Steps to get from Source file to New file:

1.  Copy/paste table (from row 5 – 57, column A – B)
2.  Fill province column manually
3.  Split column B on : to separate district name from district code
4.  Rename columns
5.  Export as CSV to join with za_hospital_list_refine.csv exported from OpenRefine (see readme_za_hospital_list.txt)
6.  Follow steps in readme_za_hospital_list.txt
