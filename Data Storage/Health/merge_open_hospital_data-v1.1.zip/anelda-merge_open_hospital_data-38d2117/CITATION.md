## Cite as

Anelda van der Walt. (2020, April 16). anelda/merge_open_hospital_data: Merging Open Health Facility Data Sets: Part 1 (Version v1.0). Zenodo. http://doi.org/10.5281/zenodo.3754453
